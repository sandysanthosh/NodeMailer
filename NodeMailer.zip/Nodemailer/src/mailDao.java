import java.util.*;
import java.sql.*;

public class mailDao {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(mail e){
		int status=0;
		try{
			Connection con=mailDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into mail(name,email) values (?,?)");
			ps.setString(1,e.getName());
			ps.setString(2,e.getEmail());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int update(mail e){
		int status=0;
		try{
			Connection con=mailDao.getConnection();
			PreparedStatement ps=con.prepareStatement("update mail set name=?,email=?");
			ps.setString(1,e.getName());
			ps.setString(2,e.getEmail());
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	public static int delete(int id){
		int status=0;
		try{
			Connection con=mailDao.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from mail where id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return status;
	}
	public static mail getmailloyeeById(int id){
		mail e=new mail();
		
		try{
			Connection con=mailDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from mail where id=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				e.setName(rs.getString(1));
				e.setEmail(rs.getString(2));
			}
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return e;
	}
	public static List<mail> getAllmailloyees(){
		List<mail> list=new ArrayList<mail>();
		
		try{
			Connection con=mailDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from mail");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				mail e=new mail();
				e.setName(rs.getString(1));
				e.setEmail(rs.getString(2));
				list.add(e);
			}
			con.close();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
}
